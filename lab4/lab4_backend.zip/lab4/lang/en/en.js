exports.en = {
  "404Message": "'%PATH%' not found.",
  "NoDefinitionMessasge": "No defintion found for '%WORD%'.",
  "StoreSuccessMessage": "'%WORD%' definition successfully stored.",
  "StoreErrorMessage": "Failed to store definition.",
  "BadInputErrorMessage": "Invalid or empty data recieved."
}