this.en = {
  "404Message": "'%PATH%' not found.",
  "IllegalQuery": "Query must be SELECT or INSERT only.",
  "QuerySuccess": "Successfully ran %TYPE% query.",
  "QueryFailure": "Failed to run %TYPE% query.",
  "InternalServerError": "Unexpected server error occurred.",
  "PermissionDeniedMessage": "You do not have permission to perform this query."
}