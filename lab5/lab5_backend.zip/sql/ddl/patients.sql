CREATE TABLE patients (
    patientid INT AUTO_INCREMENT,
    name VARCHAR(100),
    dateOfBirth DATETIME,
    PRIMARY KEY(patientid)
);