exports.en = {
  "DateTimeResponseMessage": "Hello %NAME%, What a beautiful day. Server current date and time is %DATESTRING%",
  "FileErrorMessage": "File: %FILENAME% doesn't exist or cannot be accessed.",
  "InvalidPathMessage": "Invalid path.",
}